<nav class="navbar navbar-expand-lg bg-body-tertiary bg-dark">
    <div class="container-md  justify-content-center">
      <a class="navbar-brand text-light" href="#"><i class="bi bi-help-fill"></i>CampusCare</a>
    </div>
</nav>