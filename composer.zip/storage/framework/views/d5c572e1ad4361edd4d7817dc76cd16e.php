

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Kelola Mahasiswa</h1>
    
  </div>

<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>





<!-- Button trigger modal -->

  
<div class="table">
    <table class="table table-striped">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Nama</th>
          <th scope="col">Nim</th>
          <th scope="col">Prodi</th>
          <th scope="col">Dosen PA</th>
          <th scope="col">Foto</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($mhs->dosenpa_id == Auth::user()->dosenpa->id): ?>
          <tr>
            <th scope="row"><?php echo e($loop->iteration); ?></th>
            <td><?php echo e($mhs->nama); ?></td>
            <td><?php echo e($mhs->nim); ?></td>
            

            <td>
              <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->id == $mhs->prodi_id): ?>
                  <?php echo e($item->nama_prodi); ?> (<?php echo e($item->jenjang); ?>)
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            
            <td><?php echo e($mhs->dosenpa->nama); ?></td>
            <td><img src="<?php echo e(asset('storage/' . $mhs->foto)); ?>" alt="foto" style="width: 50px" class="img-thumbnail"></td>
            <td>
  
              <button class="badge bg-success border-0" data-bs-toggle="modal" data-bs-target="#showmhs<?php echo e($mhs->id); ?>"><span data-feather="eye"></span></button>

              
            </td>
          </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

  <!-- Modal show Mahasiswa -->
  <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="showmhs<?php echo e($mhs->id); ?>" tabindex="-1" aria-labelledby="showmhsLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="showmhsLabel">Detail Mahasiswa</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row g-0">
                <div class="col-md-4">
                  <img src="<?php echo e(asset('storage/' . $mhs->foto)); ?>" class="img-thumbnail rounded-start" alt="<?php echo e($mhs->foto); ?>">                 
                  
                </div>
                <div class="col-md-8">
                  <div class="card-body">
                    <table class="table">
                      <tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td><?php echo e($mhs->nama); ?></td>
                      </tr>
                      <tr>
                        <td>Nim</td>
                        <td>:</td>
                        <td><?php echo e($mhs->nim); ?></td>
                      </tr>
                      <tr>
                        <td>Jenis Kelamin</td>
                        <td>:</td>
                        <td><?php echo e($mhs->jenis_kelamin); ?></td>
                      </tr>
                      <tr>
                        <td>Alamat</td>
                        <td>:</td>
                        <td><?php echo e($mhs->alamat); ?></td>
                      </tr>
                      <tr>
                        <td>Nomor HP</td>
                        <td>:</td>
                        <td><?php echo e($mhs->no_hp); ?></td>
                      </tr>
                      <tr>
                        <td>Kelas</td>
                        <td>:</td>
                        <td>
              <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->id == $mhs->prodi_id): ?>
                  <?php echo e($item->nama_prodi); ?> (<?php echo e($item->jenjang); ?>)
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
                      </tr>
                      
                      
                      <tr>
                        <td>Dosen PA</td>
                        <td>:</td>
                        <td><?php echo e($mhs->dosenpa->nama); ?></td>
                      </tr>
                    </table>
                  </div>
                </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <!-- Modal add Mahasiswa -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\pengaduan_mahasiswa\resources\views/dashboard/mhs/index.blade.php ENDPATH**/ ?>