

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Kelola Mahasiswa</h1>
</div>

<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Gagal!</strong> <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<!-- Button trigger modal -->

<button type="button" class="btn btn-primary mt-3" data-bs-toggle="modal" data-bs-target="#addmhs">
    Tambah Mahasiswa
</button>

<div class="table-responsive mt-3">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama</th>
                <th scope="col">NIM</th>
                <th scope="col">Program Studi</th>
                <th scope="col">Dosen PA</th>
                <th scope="col">Foto</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($mhs->nama); ?></td>
                    <td><?php echo e($mhs->nim); ?></td>
                    
                    <td><?php echo e($mhs->prodi->nama_prodi ?? 'N/A'); ?></td>
                    
                    <td><?php echo e($mhs->dosenpa->nama ?? 'N/A'); ?></td>
                    <td>
                        <?php if($mhs->foto): ?>
                            <img src="<?php echo e(asset('storage/' . $mhs->foto)); ?>" alt="foto" style="width: 50px; height: 50px; object-fit: cover;" class="img-thumbnail">
                        <?php else: ?>
                            <img src="https://placehold.co/50x50/666/fff?text=N/A" alt="foto" style="width: 50px" class="img-thumbnail">
                        <?php endif; ?>
                    </td>
                    <td>
                        <button class="badge bg-success border-0" data-bs-toggle="modal" data-bs-target="#showmhs<?php echo e($mhs->id); ?>"><span data-feather="eye"></span></button>
                        <button class="badge bg-warning border-0" data-bs-toggle="modal" data-bs-target="#editmhs<?php echo e($mhs->id); ?>"><span data-feather="edit"></span></button>
                        <form action="/dashboard/mahasiswa-admin/<?php echo e($mhs->id); ?>" method="post" class="d-inline">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button class="badge bg-danger border-0" onclick="return confirm('Are you sure?')"><span data-feather="trash-2"></span></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<!-- Modal show Mahasiswa -->
<?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="showmhs<?php echo e($mhs->id); ?>" tabindex="-1" aria-labelledby="showmhsLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="showmhsLabel">Detail Mahasiswa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-0">
                    <div class="col-md-4 text-center">
                         <?php if($mhs->foto): ?>
                            <img src="<?php echo e(asset('storage/' . $mhs->foto)); ?>" class="img-fluid rounded" alt="<?php echo e($mhs->foto); ?>">
                        <?php else: ?>
                            <img src="https://placehold.co/200x200/666/fff?text=N/A" class="img-fluid rounded" alt="Tidak ada foto">
                        <?php endif; ?>
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <table class="table table-borderless table-sm">
                                <tr><td>Nama</td><td>:</td><td><?php echo e($mhs->nama); ?></td></tr>
                                <tr><td>NIM</td><td>:</td><td><?php echo e($mhs->nim); ?></td></tr>
                                
                                <tr><td>Program Studi</td><td>:</td><td><?php echo e($mhs->prodi->nama_prodi ?? 'N/A'); ?> (<?php echo e($mhs->prodi->jenjang ?? 'N/A'); ?>)</td></tr>
                                <tr><td>Fakultas</td><td>:</td><td><?php echo e($mhs->prodi->fakultas->nama_fakultas ?? 'N/A'); ?></td></tr>
                                <tr><td>Dosen PA</td><td>:</td><td><?php echo e($mhs->dosenpa->nama ?? 'N/A'); ?></td></tr>
                                <tr><td>Email</td><td>:</td><td><?php echo e($mhs->user->email ?? $mhs->email); ?></td></tr>
                                <tr><td>Jenis Kelamin</td><td>:</td><td><?php echo e($mhs->jenis_kelamin); ?></td></tr>
                                <tr><td>Nomor HP</td><td>:</td><td><?php echo e($mhs->no_hp); ?></td></tr>
                                <tr><td>Alamat</td><td>:</td><td><?php echo e($mhs->alamat); ?></td></tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Modal add Mahasiswa -->
<div class="modal fade" id="addmhs" tabindex="-1" aria-labelledby="addmhsLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addmhsLabel">Tambah Mahasiswa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="/dashboard/mahasiswa-admin" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3"><label for="nama" class="form-label">Nama</label><input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" name="nama" value="<?php echo e(old('nama')); ?>" required><?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="mb-3"><label for="nim" class="form-label">NIM</label><input type="text" class="form-control <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nim" name="nim" value="<?php echo e(old('nim')); ?>" required><?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="mb-3"><label for="email" class="form-label">Email</label><input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email')); ?>" required><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="mb-3"><label for="password" class="form-label">Password</label><input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" required><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="mb-3"><label for="prodi_id" class="form-label">Program Studi</label><select class="form-select <?php $__errorArgs = ['prodi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prodi_id" required><option value="" selected disabled>Pilih Program Studi...</option><?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($p->id); ?>" <?php echo e(old('prodi_id') == $p->id ? 'selected' : ''); ?>><?php echo e($p->nama_prodi); ?> (<?php echo e($p->jenjang); ?>)</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['prodi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="mb-3"><label for="dosenpa_id" class="form-label">Dosen PA</label><select class="form-select <?php $__errorArgs = ['dosenpa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dosenpa_id" required><option value="" selected disabled>Pilih Dosen PA...</option><?php $__currentLoopData = $dosenpa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($dosen->id); ?>" <?php echo e(old('dosenpa_id') == $dosen->id ? 'selected' : ''); ?>><?php echo e($dosen->nama); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['dosenpa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="mb-3"><label for="jenis_kelamin" class="form-label">Jenis Kelamin</label><select class="form-select <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jenis_kelamin" required><option value="" selected disabled>Pilih Jenis Kelamin...</option><option value="Laki-laki" <?php echo e(old('jenis_kelamin') == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option><option value="Perempuan" <?php echo e(old('jenis_kelamin') == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option></select><?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="mb-3"><label for="no_hp" class="form-label">Nomor HP</label><input type="text" class="form-control <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_hp" name="no_hp" value="<?php echo e(old('no_hp')); ?>" required><?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="mb-3"><label for="alamat" class="form-label">Alamat</label><textarea class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat" name="alamat" required><?php echo e(old('alamat')); ?></textarea><?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="mb-3"><label for="foto" class="form-label">Foto</label><input type="file" class="form-control <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="foto" name="foto"><?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal edit Mahasiswa -->
<?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="editmhs<?php echo e($mhs->id); ?>" tabindex="-1" aria-labelledby="editmhsLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editmhsLabel">Edit Mahasiswa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="/dashboard/mahasiswa-admin/<?php echo e($mhs->id); ?>" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="mb-3"><label for="nama" class="form-label">Nama</label><input type="text" class="form-control" name="nama" value="<?php echo e($mhs->nama); ?>" required></div>
                    <div class="mb-3"><label for="nim" class="form-label">NIM</label><input type="text" class="form-control" name="nim" value="<?php echo e($mhs->nim); ?>" required></div>
                    <div class="mb-3"><label for="email" class="form-label">Email</label><input type="email" class="form-control" name="email" value="<?php echo e($mhs->user->email ?? $mhs->email); ?>" required></div>
                    <div class="mb-3"><label for="prodi_id" class="form-label">Program Studi</label><select class="form-select" name="prodi_id" required><option disabled>Pilih Program Studi...</option><?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($p->id); ?>" <?php echo e($mhs->prodi_id == $p->id ? 'selected' : ''); ?>><?php echo e($p->nama_prodi); ?> (<?php echo e($p->jenjang); ?>)</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <div class="mb-3"><label for="dosenpa_id" class="form-label">Dosen PA</label><select class="form-select" name="dosenpa_id" required><option disabled>Pilih Dosen PA...</option><?php $__currentLoopData = $dosenpa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($dosen->id); ?>" <?php echo e($mhs->dosenpa_id == $dosen->id ? 'selected' : ''); ?>><?php echo e($dosen->nama); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <div class="mb-3"><label for="jenis_kelamin" class="form-label">Jenis Kelamin</label><select class="form-select" name="jenis_kelamin" required><option disabled>Pilih Jenis Kelamin...</option><option value="Laki-laki" <?php echo e($mhs->jenis_kelamin == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option><option value="Perempuan" <?php echo e($mhs->jenis_kelamin == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option></select></div>
                    <div class="mb-3"><label for="no_hp" class="form-label">Nomor HP</label><input type="text" class="form-control" name="no_hp" value="<?php echo e($mhs->no_hp); ?>" required></div>
                    <div class="mb-3"><label for="alamat" class="form-label">Alamat</label><textarea class="form-control" name="alamat" required><?php echo e($mhs->alamat); ?></textarea></div>
                    <div class="mb-3"><label for="foto" class="form-label">Foto</label><?php if($mhs->foto): ?><img src="<?php echo e(asset('storage/' . $mhs->foto)); ?>" class="img-preview img-fluid mb-3 col-sm-5 d-block"><?php endif; ?><input type="file" class="form-control" name="foto"></div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\pengaduan_mahasiswa\resources\views/dashboard/mhs/foradmin.blade.php ENDPATH**/ ?>