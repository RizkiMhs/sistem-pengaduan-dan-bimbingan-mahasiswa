

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Detail Bimbingan</h1>
    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">
        <span data-feather="arrow-left"></span> Kembali
    </a>
</div>

<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Gagal!</strong> <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<div class="row">
    
    <div class="col-lg-8">
        
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Detail Pengajuan dari: <strong><?php echo e($pendaftaran->mahasiswa->nama); ?></strong></span>
                <?php if($pendaftaran->status_pengajuan == 'Diterima'): ?>
                    <span class="badge bg-success"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                <?php elseif($pendaftaran->status_pengajuan == 'Ditolak'): ?>
                    <span class="badge bg-danger"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                <?php elseif($pendaftaran->status_pengajuan == 'Selesai'): ?>
                    <span class="badge bg-secondary"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                <?php else: ?>
                    <span class="badge bg-warning text-dark"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <dl class="row">
                    <dt class="col-sm-4">Topik Ajuan</dt>
                    <dd class="col-sm-8"><?php echo e($pendaftaran->topik_mahasiswa); ?></dd>

                    <dt class="col-sm-4">Deskripsi</dt>
                    <dd class="col-sm-8"><?php echo e($pendaftaran->deskripsi_mahasiswa); ?></dd>

                    <dt class="col-sm-4">Dokumen Pendukung</dt>
                    <dd class="col-sm-8">
                        <?php if($pendaftaran->dokumen_mahasiswa): ?>
                            <a href="<?php echo e(asset('storage/' . $pendaftaran->dokumen_mahasiswa)); ?>" target="_blank">Unduh Dokumen</a>
                        <?php else: ?>
                            <span class="text-muted">Tidak ada dokumen.</span>
                        <?php endif; ?>
                    </dd>
                </dl>
            </div>
        </div>

        
        <?php if($pendaftaran->status_pengajuan == 'Diterima' || $pendaftaran->status_pengajuan == 'Selesai'): ?>
        <div class="card mb-4">
            <div class="card-header">Hasil & Catatan Bimbingan</div>
            <div class="card-body">
                <dl class="row">
                    <dt class="col-sm-4">Catatan dari Dosen</dt>
                    <dd class="col-sm-8"><?php echo e(optional($pendaftaran->catatanBimbingan)->catatan_dosen ?? 'Belum ada catatan dari dosen.'); ?></dd>

                    <dt class="col-sm-4">Dokumen Revisi</dt>
                    <dd class="col-sm-8">
                         <?php if(optional($pendaftaran->catatanBimbingan)->dokumen_revisi_dosen): ?>
                            <a href="<?php echo e(asset('storage/' . $pendaftaran->catatanBimbingan->dokumen_revisi_dosen)); ?>" target="_blank">Unduh Dokumen Revisi</a>
                        <?php else: ?>
                            <span class="text-muted">Tidak ada dokumen.</span>
                        <?php endif; ?>
                    </dd>

                    <dt class="col-sm-4">Catatan Konfirmasi Mahasiswa</dt>
                    <dd class="col-sm-8"><?php echo e(optional($pendaftaran->catatanBimbingan)->catatan_mahasiswa ?? 'Belum ada catatan dari mahasiswa.'); ?></dd>
                </dl>
            </div>
        </div>
        <?php endif; ?>
    </div>

    
    <div class="col-lg-4">
        
        <div class="card mb-4">
            <div class="card-header">
                Informasi Jadwal
            </div>
             <ul class="list-group list-group-flush">
                <li class="list-group-item"><strong>Dosen PA:</strong> <?php echo e($pendaftaran->jadwalBimbingan->dosenpa->nama); ?></li>
                <li class="list-group-item"><strong>Kategori:</strong> <?php echo e($pendaftaran->jadwalBimbingan->kategoriBimbingan->nama_kategori); ?></li>
                <li class="list-group-item"><strong>Waktu:</strong> <?php echo e(\Carbon\Carbon::parse($pendaftaran->jadwalBimbingan->waktu_mulai)->format('l, d M Y, H:i')); ?></li>
            </ul>
        </div>
        
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dosen_pa')): ?>
            
            <?php if($pendaftaran->status_pengajuan == 'Diajukan'): ?>
            <div class="card mb-4">
                <div class="card-header">Tindak Lanjut Pengajuan</div>
                <div class="card-body text-center">
                    <p>Silakan terima atau tolak pengajuan bimbingan ini.</p>
                    <form action="<?php echo e(route('dashboard.dosen.pengajuan-masuk.update', $pendaftaran->id)); ?>" method="post" class="d-inline">
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="status_pengajuan" value="Ditolak">
                        <button type="submit" class="btn btn-danger">Tolak</button>
                    </form>
                    <form action="<?php echo e(route('dashboard.dosen.pengajuan-masuk.update', $pendaftaran->id)); ?>" method="post" class="d-inline">
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="status_pengajuan" value="Diterima">
                        <button type="submit" class="btn btn-success">Terima</button>
                    </form>
                </div>
            </div>
            <?php endif; ?>

            
            <?php if($pendaftaran->status_pengajuan == 'Diterima' || $pendaftaran->status_pengajuan == 'Selesai'): ?>
            <div class="card">
                <div class="card-header">Form Catatan (Dosen)</div>
                <div class="card-body">
                    <form action="<?php echo e(route('dashboard.catatan-bimbingan.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="pendaftaran_id" value="<?php echo e($pendaftaran->id); ?>">
                        <div class="mb-3">
                            <label for="catatan_dosen" class="form-label">Catatan/Feedback</label>
                            <textarea name="catatan_dosen" class="form-control" rows="5" required><?php echo e(old('catatan_dosen', optional($pendaftaran->catatanBimbingan)->catatan_dosen ?? '')); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="dokumen_revisi_dosen" class="form-label">Upload Dokumen Revisi (Opsional)</label>
                            <input type="file" name="dokumen_revisi_dosen" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Simpan Catatan & Selesaikan</button>
                    </form>
                </div>
            </div>
            <?php endif; ?>
        <?php endif; ?>

        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mahasiswa')): ?>
            <?php if($pendaftaran->status_pengajuan == 'Selesai'): ?>
            <div class="card">
                <div class="card-header">Form Catatan Konfirmasi</div>
                <div class="card-body">
                    <form action="<?php echo e(route('dashboard.catatan-bimbingan.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="pendaftaran_id" value="<?php echo e($pendaftaran->id); ?>">
                        <div class="mb-3">
                            <label for="catatan_mahasiswa" class="form-label">Catatan Konfirmasi</label>
                            <textarea name="catatan_mahasiswa" class="form-control" rows="5" placeholder="Contoh: Baik, Pak/Bu. Catatan sudah saya terima dan akan segera saya perbaiki."><?php echo e(old('catatan_mahasiswa', optional($pendaftaran->catatanBimbingan)->catatan_mahasiswa ?? '')); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Simpan Konfirmasi</button>
                    </form>
                </div>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\pengaduan_mahasiswa\resources\views/dashboard/pendaftaran_bimbingan/show.blade.php ENDPATH**/ ?>