

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Riwayat Pengaduan</h1>
</div>

<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>


<div class="table">
    <table class="table table-hover">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">NIM</th>
                <th scope="col">Nama Mahasiswa</th>
                <th scope="col">Isi Pengaduan</th>
                <th scope="col">isi Tanggapan</th>
                <th scope="col">Tanggal Masuk</th>
                <th scope="col">Status</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tanggapan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->pengaduan->status == 'selesai'): ?>
            <?php if($item->dosenpa_id == Auth::user()->dosenpa->id): ?>
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($item->pengaduan->mahasiswa->nim); ?></td>
                <td><?php echo e($item->pengaduan->mahasiswa->nama); ?></td>
                <td><?php echo e($item->pengaduan->isi_pengaduan); ?></td>
                <td><?php echo e($item->isi_tanggapan); ?></td>
                <td><?php echo e($item->pengaduan->created_at); ?></td>
                <td>
                    <?php if($item->pengaduan->status == 'proses'): ?>
                    <span class="badge bg-warning text-dark"><?php echo e($item->pengaduan->status); ?></span>
                    <?php else: ?>
                    <span class="badge bg-success"><?php echo e($item->pengaduan->status); ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <button class="badge bg-success border-0" data-bs-toggle="modal" data-bs-target="#showtanggapan<?php echo e($item->id); ?>"><span data-feather="eye"></span></button>
                </td>
            </tr>
            <?php endif; ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>

</div>


<?php $__currentLoopData = $tanggapan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="showtanggapan<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Detail Tanggapan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body
                ">
                <div class="row">
                    <div class="col-md-5">
                        <img src="<?php echo e(asset('storage/' . $item->pengaduan->foto)); ?>" alt="<?php echo e($item->pengaduan->isi_pengaduan); ?>" class="img-thumbnail" width="300">
                    </div>
                    <div class="col-md-7">
                        <ul class="list-group">
                            <li class="list-group-item"><strong>NIM Mahasiswa:</strong> <?php echo e($item->pengaduan->mahasiswa->nim); ?></li>  
                            <li class="list-group-item"><strong>Nama Mahasiswa:</strong> <?php echo e($item->pengaduan->mahasiswa->nama); ?></li>
                            <li class="list-group-item"><strong>Isi Pengaduan:</strong> <?php echo e($item->pengaduan->isi_pengaduan); ?></li>
                            <li class="list-group-item"><strong>Tanggapan:</strong> <?php echo e($item->isi_tanggapan); ?></li>
                            <li class="list-group-item"><strong>Status:</strong> <?php echo e($item->pengaduan->status); ?></li>
                            <li class="list-group-item"><strong>Tanggal Masuk:</strong> <?php echo e($item->pengaduan->created_at); ?></li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\pengaduan_mahasiswa\resources\views/dashboard/tanggapan/index.blade.php ENDPATH**/ ?>