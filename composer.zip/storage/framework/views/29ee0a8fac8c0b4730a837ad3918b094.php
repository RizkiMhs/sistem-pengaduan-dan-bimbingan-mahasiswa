

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Selamat Datang, <?php echo e(Auth::user()->name); ?> ( <?php echo e(Auth::user()->role); ?> )</h1>
</div>




<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
<div class="row gy-4">
    
    <div class="col-md-4">
        <div class="card bg-secondary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="user-plus" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalDosenpa); ?></h1>
                </div>
                Total Dosen PA
            </div>
        </div>
    </div>
     
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="users" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalMahasiswa); ?></h1>
                </div>
                Total Mahasiswa
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="slack" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalPengaduan); ?></h1>
                </div>
                Total Pengaduan Masuk
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="check-circle" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalTanggapan); ?></h1>
                </div>
                Total Pengaduan Selesai
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="alert-circle" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalPengaduanProses); ?></h1>
                </div>
                Total Pengaduan Proses
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card bg-dark text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="calendar" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalJadwalBimbingan); ?></h1>
                </div>
                Total Jadwal Bimbingan
            </div>
        </div>
    </div>
</div>
<?php endif; ?>




<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dosen_pa')): ?>
<div class="row gy-4">
    
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="users" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalMahasiswa); ?></h1>
                </div>
                Total Mahasiswa Bimbingan
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card bg-dark text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="calendar" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalJadwalDibuat); ?></h1>
                </div>
                Total Jadwal Dibuat
            </div>
        </div>
    </div>
     
    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="file-text" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalPengajuanMasuk); ?></h1>
                </div>
                Total Pengajuan Masuk
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card bg-primary text-white" style="background-color: #6f42c1 !important;">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="slack" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalPengaduan); ?></h1>
                </div>
                Total Pengaduan Masuk
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="check-circle" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalTanggapan); ?></h1>
                </div>
                Total Pengaduan Selesai
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="alert-circle" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalPengaduanProses); ?></h1>
                </div>
                Total Pengaduan Proses
            </div>
        </div>
    </div>
</div>
<?php endif; ?>




<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mahasiswa')): ?>
<div class="row gy-4">
    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="send" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalPengaduanAnda); ?></h1>
                </div>
                Total Pengaduan Anda
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="check-square" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalPengaduanSelesai); ?></h1>
                </div>
                Pengaduan Selesai
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="clock" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalPengaduanProses); ?></h1>
                </div>
                Pengaduan Diproses
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span data-feather="calendar" style="width: 48px; height: 48px;"></span>
                    <h1 class="display-4"><?php echo e($totalBimbingan); ?></h1>
                </div>
                Total Pengajuan Bimbingan
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\pengaduan_mahasiswa\resources\views/dashboard/index.blade.php ENDPATH**/ ?>