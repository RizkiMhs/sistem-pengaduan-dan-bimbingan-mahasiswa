

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Laporan Rekap Rating Dosen</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="<?php echo e(route('dashboard.admin.export.rating')); ?>" class="btn btn-outline-primary mb-3">Ekspor PDF</a>
            </div>
        </div>
    </div>

    <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>


        
        <form action="/dashboard/tanggapanforadmin" method="get">
            <div class="row mb-3">
                <div class="col-md-5">
                    <label for="start" class="form-label">Dari Tanggal</label>
                    <input type="date" class="form-control" id="start" name="start">
                </div>
                <div class="col-md-5">
                    <label for="end" class="form-label">Sampai Tanggal</label>
                    <input type="date" class="form-control" id="end" name="end">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-success mt-4">Filter</button>
                </div>
            </div>
        </form>
    
        
        <form action="/dashboard/ratingdosen" method="get">
            <div class="input-group mb-3">
                <input type="text" class="form-control" placeholder="Cari Pengaduan" name="cari">
                <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Cari</button>
            </div>
        </form>

    <div class="table">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nama Dosen</th>
                    <th scope="col">NIPN Dosen</th>
                    <th scope="col">Rating</th>
                    <th scope="col">Nilai</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dosenpa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td>
                        <?php echo e($item->nama); ?>

                    </td>
                    <td>
                        <?php echo e($item->nidn); ?>

                    </td>
                    <td>
                        <?php if($item->rating->count()): ?>
                            <?php
                                $hasil = $item->rating->avg('rating');
                                $bulat = round($hasil);
                            ?>
                            <?php for($i = 0; $i < $bulat; $i++): ?>
                                <span data-feather="star" class="text-warning"></span>
                            <?php endfor; ?>
                        <?php else: ?>
                            Belum ada rating
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($item->rating->count()): ?>
                            <?php
                                $hasil = $item->rating->avg('rating');
                                $bulat = round($hasil);
                            ?>
                            <?php if($bulat == 1): ?>
                                Sangat Kurang
                            <?php elseif($bulat == 2): ?>
                                Kurang
                            <?php elseif($bulat == 3): ?>
                                Cukup
                            <?php elseif($bulat == 4): ?>
                                Baik
                            <?php elseif($bulat == 5): ?>
                                Sangat Baik
                            <?php endif; ?>
                        <?php else: ?>
                            Belum ada penilaian
                        <?php endif; ?>
                    </td>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\pengaduan_mahasiswa\resources\views/dashboard/rating/admin/index.blade.php ENDPATH**/ ?>