

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Pendaftaran Bimbingan</h1>
</div>

<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Gagal!</strong> <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>


<div class="card mb-4">
    <div class="card-header">
        <h5>Jadwal Bimbingan Tersedia</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">Dosen PA</th>
                        <th scope="col">Kategori</th>
                        <th scope="col">Topik Umum</th>
                        <th scope="col">Waktu</th>
                        <th scope="col">Kuota</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $jadwalTersedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($jadwal->dosenpa->nama); ?></td>
                            <td><?php echo e($jadwal->kategoriBimbingan->nama_kategori); ?></td>
                            <td><?php echo e($jadwal->topik_umum); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($jadwal->waktu_mulai)->format('d M Y, H:i')); ?></td>
                            <td><?php echo e($jadwal->pendaftaranBimbingan->where('status_pengajuan', 'Diterima')->count()); ?> / <?php echo e($jadwal->kuota_per_hari); ?></td>
                            <td>
                                <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#ajukanBimbinganModal" data-jadwal-id="<?php echo e($jadwal->id); ?>" data-jadwal-topik="<?php echo e($jadwal->topik_umum); ?>">
                                    Ajukan Bimbingan
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">Saat ini tidak ada jadwal bimbingan yang tersedia.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<div class="card">
    <div class="card-header">
        <h5>Riwayat Pengajuan Bimbingan Anda</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Topik Ajuan</th>
                        <th scope="col">Jadwal Dosen</th>
                        <th scope="col">Tanggal Pengajuan</th>
                        <th scope="col">Status</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendaftaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($pendaftaran->topik_mahasiswa); ?></td>
                            <td><?php echo e($pendaftaran->jadwalBimbingan->dosenpa->nama); ?> - <?php echo e(\Carbon\Carbon::parse($pendaftaran->jadwalBimbingan->waktu_mulai)->format('d M Y, H:i')); ?></td>
                            <td><?php echo e($pendaftaran->created_at->format('d M Y')); ?></td>
                            <td>
                                <?php if($pendaftaran->status_pengajuan == 'Diterima'): ?>
                                    <span class="badge bg-success"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                                <?php elseif($pendaftaran->status_pengajuan == 'Ditolak'): ?>
                                    <span class="badge bg-danger"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                                <?php elseif($pendaftaran->status_pengajuan == 'Selesai'): ?>
                                    <span class="badge bg-secondary"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                
                                <a href="<?php echo e(route('dashboard.mahasiswa.pendaftaran-bimbingan.show', $pendaftaran->id)); ?>" class="badge bg-info"><span data-feather="eye"></span></a>

                                <?php if($pendaftaran->status_pengajuan == 'Diajukan'): ?>
                                    
                                    <form action="<?php echo e(route('dashboard.mahasiswa.pendaftaran-bimbingan.destroy', $pendaftaran->id)); ?>" method="post" class="d-inline">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="badge bg-danger border-0" onclick="return confirm('Anda yakin ingin membatalkan pengajuan ini?')"><span data-feather="x-circle"></span></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">Anda belum pernah mengajukan bimbingan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Ajukan Bimbingan -->
<div class="modal fade" id="ajukanBimbinganModal" tabindex="-1" aria-labelledby="ajukanBimbinganModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ajukanBimbinganModalLabel">Form Pengajuan Bimbingan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                
                <form method="post" action="<?php echo e(route('dashboard.mahasiswa.pendaftaran-bimbingan.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="jadwal_bimbingan_id" id="jadwal_id_input">
                    <p>Anda akan mendaftar untuk jadwal: <strong id="jadwal_topik_text"></strong></p>

                    <div class="mb-3">
                        <label for="topik_mahasiswa" class="form-label">Topik Spesifik Anda</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['topik_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="topik_mahasiswa" value="<?php echo e(old('topik_mahasiswa')); ?>" required>
                        <?php $__errorArgs = ['topik_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="deskripsi_mahasiswa" class="form-label">Deskripsi/Pertanyaan</label>
                        <textarea class="form-control <?php $__errorArgs = ['deskripsi_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="deskripsi_mahasiswa" rows="4" required><?php echo e(old('deskripsi_mahasiswa')); ?></textarea>
                        <?php $__errorArgs = ['deskripsi_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="dokumen_mahasiswa" class="form-label">Dokumen Pendukung (Opsional)</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['dokumen_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dokumen_mahasiswa">
                        <?php $__errorArgs = ['dokumen_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Kirim Pengajuan</button>
                </form>
            </div>
        </div>
    </div>
</div>



<script>
    const ajukanBimbinganModal = document.getElementById('ajukanBimbinganModal');
    if (ajukanBimbinganModal) {
        ajukanBimbinganModal.addEventListener('show.bs.modal', event => {
            const button = event.relatedTarget;
            const jadwalId = button.getAttribute('data-jadwal-id');
            const jadwalTopik = button.getAttribute('data-jadwal-topik');
            
            const modalJadwalIdInput = ajukanBimbinganModal.querySelector('#jadwal_id_input');
            const modalJadwalTopikText = ajukanBimbinganModal.querySelector('#jadwal_topik_text');

            modalJadwalIdInput.value = jadwalId;
            modalJadwalTopikText.textContent = jadwalTopik;
        });
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\pengaduan_mahasiswa\resources\views/dashboard/pendaftaran_bimbingan/mahasiswa_index.blade.php ENDPATH**/ ?>