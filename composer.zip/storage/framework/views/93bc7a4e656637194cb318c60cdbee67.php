

<?php $__env->startSection('container'); ?>
<style>
    /* Menambahkan sedikit style untuk background */
    body {
        background-color: #f8f9fa;
    }
</style>


<div class="container col-xl-10 col-xxl-8 px-4 py-5">
    
    
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <div class="row align-items-center g-lg-5 py-5">
        
        <div class="col-lg-7 text-center text-lg-start">
            <h1 class="display-4 fw-bold lh-1 mb-3">CampusCare</h1>
            <p class="col-lg-10 fs-4">Layanan terintegrasi untuk pengaduan dan bimbingan mahasiswa. Sampaikan aspirasi dan keluhan Anda, atau atur jadwal bimbingan dengan mudah bersama Dosen Pembimbing Akademik Anda.</p>
        </div>

        
        <div class="col-md-10 mx-auto col-lg-5">
            <div class="card shadow-lg border-0">
                <div class="card-body p-4 p-md-5">
                    <div class="text-center mb-4">
                        <span data-feather="send" class="text-primary" style="width: 48px; height: 48px;"></span>
                        <h2 class="h3 fw-bold mt-2">Login Akun</h2>
                        <p class="text-muted">Silakan masuk untuk melanjutkan</p>
                    </div>

                    <form action="/login" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="name@example.com" required autofocus>
                            <label for="email">Alamat Email</label>
                            
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                            <label for="password">Password</label>
                        </div>

                        <button class="w-100 btn btn-lg btn-primary" type="submit">Masuk</button>
                        <hr class="my-4">
                        <small class="text-muted d-block text-center">Layanan Pengaduan & Bimbingan Mahasiswa.</small>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\pengaduan_mahasiswa\resources\views/home.blade.php ENDPATH**/ ?>