

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Profil Saya</h1>
</div>

<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>


<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<div class="row">
    <div class="col-lg-4">
        
        <div class="card mb-4">
            <div class="card-header">Ganti Foto Profil</div>
            <div class="card-body text-center">
                 <?php
                    $foto = 'https://ui-avatars.com/api/?name=' . urlencode($user->name) . '&background=random&color=fff';
                    if ($user->mahasiswa && $user->mahasiswa->foto) {
                        $foto = asset('storage/' . $user->mahasiswa->foto);
                    } elseif ($user->dosenpa && $user->dosenpa->foto) {
                        $foto = asset('storage/' . $user->dosenpa->foto);
                    }
                ?>
                <img src="<?php echo e($foto); ?>" class="img-thumbnail mb-3" alt="Foto Profil" width="300" height="300" style="object-fit: cover;">
                
                <form action="<?php echo e(route('dashboard.profile.photo.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <input class="form-control form-control-sm" id="foto" name="foto" type="file" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm">Upload Foto Baru</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        
        <div class="card">
            <div class="card-header">Ganti Password</div>
            <div class="card-body">
                <form action="<?php echo e(route('dashboard.profile.password.update')); ?>" method="POST">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                     <div class="mb-3">
                        <label for="current_password" class="form-label">Password Saat Ini</label>
                        <input type="password" class="form-control" name="current_password" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password Baru</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="password_confirmation" class="form-label">Konfirmasi Password Baru</label>
                        <input type="password" class="form-control" name="password_confirmation" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Ubah Password</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\pengaduan_mahasiswa\resources\views/dashboard/profile/index.blade.php ENDPATH**/ ?>