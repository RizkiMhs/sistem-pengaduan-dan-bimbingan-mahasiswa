

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Pengajuan Bimbingan Masuk</h1>
</div>

<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Gagal!</strong> <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h5>Daftar Pengajuan dari Mahasiswa</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama Mahasiswa</th>
                        <th scope="col">Topik Ajuan</th>
                        <th scope="col">Jadwal Dipilih</th>
                        <th scope="col">Tgl. Pengajuan</th>
                        <th scope="col">Status</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendaftaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($pendaftaran->mahasiswa->nama); ?></td>
                            <td><?php echo e($pendaftaran->topik_mahasiswa); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($pendaftaran->jadwalBimbingan->waktu_mulai)->format('d M Y, H:i')); ?></td>
                            <td><?php echo e($pendaftaran->created_at->format('d M Y')); ?></td>
                            <td>
                                <?php if($pendaftaran->status_pengajuan == 'Diterima'): ?>
                                    <span class="badge bg-success"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                                <?php elseif($pendaftaran->status_pengajuan == 'Ditolak'): ?>
                                    <span class="badge bg-danger"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                                <?php elseif($pendaftaran->status_pengajuan == 'Selesai'): ?>
                                    <span class="badge bg-secondary"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark"><?php echo e($pendaftaran->status_pengajuan); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                
                                <a href="<?php echo e(route('dashboard.dosen.pengajuan-masuk.show', $pendaftaran->id)); ?>" class="badge bg-info"><span data-feather="eye"></span></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada pengajuan bimbingan yang masuk.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\pengaduan_mahasiswa\resources\views/dashboard/pendaftaran_bimbingan/dosen_index.blade.php ENDPATH**/ ?>