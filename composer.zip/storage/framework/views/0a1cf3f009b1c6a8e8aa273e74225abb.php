<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-12 border-bottom">
                <p class=" text-center fs-6">&copy; 2024 ADM. All Rights Reserved</p>
            </div>
        </div>
    </div>
</footer><?php /**PATH E:\laragon\www\pengaduan_mahasiswa\resources\views/partials/footer.blade.php ENDPATH**/ ?>